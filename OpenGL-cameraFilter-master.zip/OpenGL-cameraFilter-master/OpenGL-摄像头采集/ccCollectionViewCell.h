//
//  ccCollectionViewCell.h
//  openGL-加载图片
//
//  Created by mac on 2020/2/25.
//  Copyright © 2020 cc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ccCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UILabel* label;

@end

NS_ASSUME_NONNULL_END
